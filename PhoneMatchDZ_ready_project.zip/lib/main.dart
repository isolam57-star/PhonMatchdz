import 'package:flutter/material.dart';

void main() {
  runApp(const PhoneMatchApp());
}

class Phone {
  final String name, brand, image;
  final int price, ram, storage, battery, camera, performance;
  final double screen;
  final List<String> tags;

  const Phone({
    required this.name,
    required this.brand,
    required this.image,
    required this.price,
    required this.ram,
    required this.storage,
    required this.battery,
    required this.camera,
    required this.performance,
    required this.screen,
    required this.tags,
  });
}

const phones = <Phone>[
  Phone(name:'Samsung Galaxy A55', brand:'Samsung', image:'', price:72000, ram:8, storage:256, battery:5000, camera:50, performance:82, screen:6.6, tags:['camera','daily','work']),
  Phone(name:'Xiaomi Redmi Note 13 Pro', brand:'Xiaomi', image:'', price:59000, ram:8, storage:256, battery:5000, camera:200, performance:78, screen:6.67, tags:['camera','gaming','daily']),
  Phone(name:'POCO X6 Pro', brand:'POCO', image:'', price:68000, ram:12, storage:512, battery:5000, camera:64, performance:95, screen:6.67, tags:['gaming','performance']),
  Phone(name:'iPhone 13', brand:'Apple', image:'', price:95000, ram:4, storage:128, battery:3240, camera:12, performance:90, screen:6.1, tags:['camera','daily','work']),
  Phone(name:'Samsung Galaxy A35', brand:'Samsung', image:'', price:56000, ram:8, storage:256, battery:5000, camera:50, performance:74, screen:6.6, tags:['daily','camera','work']),
  Phone(name:'Infinix GT 20 Pro', brand:'Infinix', image:'', price:62000, ram:12, storage:256, battery:5000, camera:108, performance:91, screen:6.78, tags:['gaming','performance']),
  Phone(name:'Honor X8b', brand:'Honor', image:'', price:43000, ram:8, storage:256, battery:4500, camera:108, performance:67, screen:6.7, tags:['daily','camera','work']),
  Phone(name:'Tecno Camon 30', brand:'Tecno', image:'', price:47000, ram:8, storage:256, battery:5000, camera:50, performance:70, screen:6.78, tags:['camera','daily']),
];

class PhoneMatchApp extends StatelessWidget {
  const PhoneMatchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PhoneMatch DZ',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
        fontFamily: 'Arial',
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int budget = 60000;
  String usage = 'استعمال عادي';
  final usages = ['استعمال عادي', 'ألعاب', 'كاميرا', 'دراسة/عمل', 'بطارية'];

  List<Phone> recommend() {
    final tag = switch (usage) {
      'ألعاب' => 'gaming',
      'كاميرا' => 'camera',
      'دراسة/عمل' => 'work',
      _ => 'daily'
    };
    final list = phones.where((p) => p.price <= budget * 1.12).toList();
    list.sort((a,b) => score(b, tag).compareTo(score(a, tag)));
    return list;
  }

  double score(Phone p, String tag) {
    double s = 0;
    s += p.price <= budget ? 30 : 18;
    s += (p.tags.contains(tag) ? 30 : 10);
    s += p.performance * 0.15;
    s += (p.battery / 5000) * 12;
    s += (p.ram / 12) * 8;
    s += (p.storage / 512) * 5;
    if (tag == 'camera') s += (p.camera / 200) * 15;
    return s;
  }

  String money(int n) => '${n.toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]} ')} دج';

  @override
  Widget build(BuildContext context) {
    final results = recommend();
    return Scaffold(
      appBar: AppBar(
        title: const Text('PhoneMatch DZ', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('اعثر على الهاتف المناسب لك', textAlign: TextAlign.center,
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('أدخل ميزانيتك واختر طريقة استعمالك، وسنرتب لك أفضل الخيارات.',
              textAlign: TextAlign.center),
          const SizedBox(height: 24),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text('الميزانية: ${money(budget)}', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                Slider(
                  value: budget.toDouble(), min: 20000, max: 150000, divisions: 130,
                  label: money(budget),
                  onChanged: (v) => setState(() => budget = v.round()),
                ),
                const SizedBox(height: 8),
                const Text('نوع الاستعمال', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8, runSpacing: 8,
                  children: usages.map((u) => ChoiceChip(
                    label: Text(u),
                    selected: usage == u,
                    onSelected: (_) => setState(() => usage = u),
                  )).toList(),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 24),
          Text('أفضل الخيارات لك', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 10),
          if (results.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(20),
              child: Text('لا يوجد هاتف ضمن هذه الميزانية. جرّب زيادة الميزانية قليلاً.')))
          else
            ...results.take(5).map((p) => _PhoneCard(
              phone: p, price: money(p.price),
              compatibility: score(p, usage == 'ألعاب' ? 'gaming' : usage == 'كاميرا' ? 'camera' : usage == 'دراسة/عمل' ? 'work' : 'daily').round(),
            )),
        ],
      ),
    );
  }
}

class _PhoneCard extends StatelessWidget {
  final Phone phone; final String price; final int compatibility;
  const _PhoneCard({required this.phone, required this.price, required this.compatibility});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        contentPadding: const EdgeInsets.all(14),
        leading: CircleAvatar(
          radius: 28,
          child: Text(phone.brand.substring(0,1)),
        ),
        title: Text(phone.name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('$price\nRAM ${phone.ram}GB • ${phone.storage}GB • بطارية ${phone.battery}mAh'),
        isThreeLine: true,
        trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text('$compatibility%', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          const Text('توافق'),
        ]),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailsPage(phone: phone))),
      ),
    );
  }
}

class DetailsPage extends StatelessWidget {
  final Phone phone;
  const DetailsPage({super.key, required this.phone});

  String money(int n) => '${n.toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]} ')} دج';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(phone.name)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          CircleAvatar(radius: 55, child: Text(phone.brand.substring(0,1), style: const TextStyle(fontSize: 38))),
          const SizedBox(height: 16),
          Text(phone.name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          Text(phone.brand, textAlign: TextAlign.center),
          const SizedBox(height: 20),
          Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
            _row('السعر التقريبي', money(phone.price)),
            _row('الرام', '${phone.ram} GB'),
            _row('التخزين', '${phone.storage} GB'),
            _row('البطارية', '${phone.battery} mAh'),
            _row('الكاميرا الرئيسية', '${phone.camera} MP'),
            _row('الأداء', '${phone.performance}/100'),
            _row('الشاشة', '${phone.screen}"'),
          ]))),
          const SizedBox(height: 16),
          const Text('ملاحظة: الأسعار الموجودة في النسخة التجريبية قابلة للتغيير، ويجب تحديثها قبل الاعتماد عليها في الشراء.',
              textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _row(String a, String b) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 9),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(a), Text(b, style: const TextStyle(fontWeight: FontWeight.bold)),
    ]),
  );
}
