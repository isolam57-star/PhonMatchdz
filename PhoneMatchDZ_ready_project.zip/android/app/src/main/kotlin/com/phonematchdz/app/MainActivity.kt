package com.phonematchdz.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
