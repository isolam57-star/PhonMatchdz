# PhoneMatch DZ

نسخة أولى جاهزة من تطبيق اختيار الهاتف المناسب حسب الميزانية والاستعمال.

## التشغيل
1. ثبّت Flutter وAndroid Studio.
2. افتح هذا المجلد في Android Studio أو VS Code.
3. نفّذ:
   flutter pub get
   flutter run

## إخراج APK
flutter build apk --release

النسخة الحالية تعمل محليًا بدون Supabase أو API، وتحتوي على قاعدة بيانات تجريبية لـ 8 هواتف وخوارزمية ترشيح.
المرحلة التالية يمكن أن تضيف Supabase، تحديث الأسعار، صور الهواتف، البحث، المقارنة، والإعلانات.
